package Content;

public class AD {

	private String adHeader;
	private String adDescription;
	private int adID;

}