package Content;

public class Hashtag {

	private Post postList;

	public void retrieveGroups() {
		// TODO - implement Hashtag.retrieveGroups
		throw new UnsupportedOperationException();
	}

}