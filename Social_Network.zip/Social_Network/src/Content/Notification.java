package Content;

public class Notification {

	private String data;

	public void nnotify() {
		// TODO - implement Notification.notify
		throw new UnsupportedOperationException();
	}

}