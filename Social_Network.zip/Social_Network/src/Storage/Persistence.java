package Storage;

import javax.activation.DataSource;

import Content.*;

public class Persistence implements MyPersistence {

	private DataSource connection;
	private MyPersistence instance;

	public void savePost() {
		// TODO - implement Persistence.savePost
		throw new UnsupportedOperationException();
	}

	public Post SelectPost() {
		// TODO - implement Persistence.SelectPost
		throw new UnsupportedOperationException();
	}

	public void saveUser() {
		// TODO - implement Persistence.saveUser
		throw new UnsupportedOperationException();
	}

	public User selectUser() {
		// TODO - implement Persistence.selectUser
		throw new UnsupportedOperationException();
	}


	public void saveGroup() {
		// TODO - implement Persistence.saveGroup
		throw new UnsupportedOperationException();
	}

	public Group selectGroup() {
		// TODO - implement Persistence.selectGroup
		throw new UnsupportedOperationException();
	}

	public void SQLpersistence() {
		// TODO - implement Persistence.SQLpersistence
		throw new UnsupportedOperationException();
	}

	public void createUser() {
		// TODO - implement Persistence.createUser
		throw new UnsupportedOperationException();
	}

	public void createGroup() {
		// TODO - implement Persistence.createGroup
		throw new UnsupportedOperationException();
	}


	public void createPost() {
		// TODO - implement Persistence.createPost
		throw new UnsupportedOperationException();
	}

	public MyPersistence getInstance() {
		return this.instance;
	}

	public void saveHashtag() {
		// TODO - implement Persistence.saveHashtag
		throw new UnsupportedOperationException();
	}

	public void removeHashtag() {
		// TODO - implement Persistence.removeHashtag
		throw new UnsupportedOperationException();
	}

	public void saveNotification() {
		// TODO - implement Persistence.saveNotification
		throw new UnsupportedOperationException();
	}

	public void removeNotification() {
		// TODO - implement Persistence.removeNotification
		throw new UnsupportedOperationException();
	}

	public void removeUser() {
		// TODO - implement Persistence.removeUser
		throw new UnsupportedOperationException();
	}

	public void removeGroup() {
		// TODO - implement Persistence.removeGroup
		throw new UnsupportedOperationException();
	}

	public void removePage() {
		// TODO - implement Persistence.removePage
		throw new UnsupportedOperationException();
	}

	public void removePost() {
		// TODO - implement Persistence.removePost
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param tyoe
	 */
	public void LoadDB(String tyoe) {
		// TODO - implement Persistence.LoadDB
		throw new UnsupportedOperationException();
	}

	public void saveAD() {
		// TODO - implement Persistence.saveAD
		throw new UnsupportedOperationException();
	}

	public void selectAD() {
		// TODO - implement Persistence.selectAD
		throw new UnsupportedOperationException();
	}

	public void removeAD() {
		// TODO - implement Persistence.removeAD
		throw new UnsupportedOperationException();
	}

}