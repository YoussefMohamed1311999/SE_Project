package Storage;

public class PersistenceFactory {

	/**
	 * 
	 * @param type
	 */
	public void loadMechanism(String type) {
		// TODO - implement PersistenceFactory.loadMechanism
		throw new UnsupportedOperationException();
	}

}